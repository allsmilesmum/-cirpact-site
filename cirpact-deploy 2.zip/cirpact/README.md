# CirPact — website (production)

*Collaboration that holds.*

Static single-page site. No build step, no framework, nothing to install. Image
assets are externalised and optimised (no base64 embedded in the HTML).

---

## 1. Files

```
cirpact/
├── index.html
├── styles.css
├── main.js
├── README.md
└── assets/
    └── img/
        ├── logo.svg                 # full-colour horizontal lockup (light backgrounds)
        ├── logo-reversed.svg        # reversed lockup (dark backgrounds)
        ├── logo-mark.svg            # symbol only — used as the SVG favicon
        ├── logo.png                 # raster lockup (transparent, ~2x)
        ├── favicon-32.png           # 32px PNG icon
        ├── apple-touch-icon-180.png # 180px iOS home-screen icon
        ├── og-image.svg             # social share image (export a 1200x630 PNG/JPG)
        ├── portrait-pauline.jpg     # installed — Pauline portrait (4:5)
        ├── photo-experience.jpg     # installed — Practice First (hands / notes)
        ├── photo-context.jpg        # installed — full-width context band
        └── scenes/                  # the two signature visuals, illustrated tiles
            ├── v1-centre.png v1-phone.png v1-coffee.png v1-internal.png
            ├── v1-followup.png v1-site.png v1-checkin.png
            ├── v2-centre.png v2-resources.png v2-decision.png v2-systems.png
            └── v2-community.png v2-specialist.png v2-access.png
```

---

## 2. Logo

Built from the approved logo direction and harmonised to the site's locked palette:
the interlocking mark plus the "CirPact" wordmark (Cir in Deep Ink, Pact in
Terracotta), tagline "COLLABORATION THAT HOLDS." Logo colours are the locked palette
only: Deep Ink #2B231C, Terracotta #AF5F41, Moss Green #4E6046, Warm Paper / Stone
#F4EEE2. No other colours are used.

Where it is used:
- **Header** — the mark plus the two-colour wordmark, drawn inline so it stays crisp
  and renders in the site's Lora.
- **Footer** — the reversed treatment (cream wordmark and mark) for the dark ground.
- **Favicon / site icon** — `logo-mark.svg` (the symbol), with `favicon-32.png` and
  `apple-touch-icon-180.png` as PNG fallbacks.

The wordmark uses **Lora**; for print or third-party use, self-host Lora or supply an
outlined version. `logo.svg` / `logo.png` are the standalone lockups for external use.

If a different logo file is supplied later, replace the relevant asset(s) and, for the
header/footer, swap the inline `<svg class="brand__mark">` and `.brand__word` markup.

---

## 3. Assets status

All brand and image assets are installed: the harmonised logo (header, footer,
favicon), Pauline's portrait (editorial 4:5 crop in the `#pauline` slot), and both
photographs. The portrait is a plain image swap — replace `assets/img/portrait-pauline.jpg`
(keep the 4:5 frame) to change it later.

All article rows remain **Coming soon**. Publish article 01 when a URL is supplied by
changing its `<div class="article">` to `<a class="article" href="URL">` and the tag to
"Read".

---

## 4. Preview locally

Opening `index.html` on its own looks unstyled because the browser needs the sibling
files beside it. Serve the folder instead:

```bash
cd cirpact
python3 -m http.server 8000   # then open http://localhost:8000
```

Fonts (Lora + Inter) load from Google Fonts, so a connection is needed to show the exact
typefaces; without one the layout holds on system fonts.

---

## 5. Deploy (when ready — DNS unchanged for now)

Static site: upload the whole folder with `index.html` at the root. Netlify / Cloudflare
Pages / Vercel: drag the folder in, no build command. GitHub Pages: push and enable Pages
on the branch root. Deploy to a preview URL first; do not point the domain / change DNS yet.

---

## 6. Image optimisation

Scene tiles and photographs are already optimised (photos are progressive JPEG under
~250KB each). For any new photography, serve WebP/AVIF with a JPG fallback via `<picture>`,
export at ~2x display size, quality ~72–80, and keep `width`/`height` to avoid layout shift.

---

## 7. Editing reference (structure is locked — asset swaps only)

- Site colours and type live once in `:root` at the top of `styles.css`. The logo uses
  the same locked palette as the rest of the site.
- Section colour is one class per section (`s-ink`, `s-paper`, `s-paper-2`, `s-moss`, `s-terra`).
- Motion respects `prefers-reduced-motion` and degrades to fully visible without JS.
- One action only: *Start a conversation* (`mailto:`).
- Accessibility/SEO: semantic landmarks, skip link, keyboard focus, mobile-menu `aria`,
  `lang="en-IE"`, `alt` text, title/description/OpenGraph. Export a real `og-image`
  (1200x630) for link previews.
