(function(){
  'use strict';
  const doc = document.documentElement;
  const body = document.body;
  const nav = document.getElementById('nav');
  const hero = document.querySelector('.hero');
  const burger = document.querySelector('.burger');
  const menu = document.getElementById('menu');
  let lastFocused = null;

  function updateNav(){
    if(!nav) return;
    if(nav.dataset.forceSolid === 'true' || !hero){
      nav.classList.add('solid');
      return;
    }
    const threshold = Math.max(120, hero.offsetHeight * 0.84);
    nav.classList.toggle('solid', window.scrollY > threshold);
  }

  function focusables(){
    if(!menu) return [];
    return Array.from(menu.querySelectorAll('a[href],button:not([disabled]),[tabindex]:not([tabindex="-1"])'));
  }

  function openMenu(){
    if(!menu || !burger) return;
    lastFocused = document.activeElement;
    menu.classList.add('open');
    burger.setAttribute('aria-expanded','true');
    burger.setAttribute('aria-label','Close menu');
    body.classList.add('menu-open');
    const items = focusables();
    if(items[0]) window.setTimeout(()=>items[0].focus({preventScroll:true}), 60);
  }

  function closeMenu(returnFocus=true){
    if(!menu || !burger) return;
    menu.classList.remove('open');
    burger.setAttribute('aria-expanded','false');
    burger.setAttribute('aria-label','Open menu');
    body.classList.remove('menu-open');
    if(returnFocus && lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
  }

  if(burger && menu){
    burger.addEventListener('click',()=> menu.classList.contains('open') ? closeMenu(false) : openMenu());
    menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>closeMenu(false)));
    document.addEventListener('keydown',function(e){
      if(!menu.classList.contains('open')) return;
      if(e.key === 'Escape'){
        e.preventDefault();
        closeMenu(true);
        return;
      }
      if(e.key === 'Tab'){
        const items = [burger, ...focusables()];
        if(!items.length) return;
        const first = items[0], last = items[items.length-1];
        if(e.shiftKey && document.activeElement === first){e.preventDefault();last.focus();}
        else if(!e.shiftKey && document.activeElement === last){e.preventDefault();first.focus();}
      }
    });
    window.addEventListener('resize',()=>{if(window.innerWidth>760 && menu.classList.contains('open')) closeMenu(false);},{passive:true});
  }

  updateNav();
  window.addEventListener('scroll',updateNav,{passive:true});
  window.addEventListener('resize',updateNav,{passive:true});

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const revealEls = document.querySelectorAll('.rv');
  if(reduced || !('IntersectionObserver' in window)){
    revealEls.forEach(el=>el.classList.add('in'));
  } else {
    const io = new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){entry.target.classList.add('in');io.unobserve(entry.target);}
      });
    },{threshold:.1,rootMargin:'0px 0px -30px 0px'});
    revealEls.forEach(el=>io.observe(el));
  }
})();
